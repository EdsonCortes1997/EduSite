package com.softtek.web.cursos.web.pages.controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.softtek.web.cursos.web.entity.Courses;
import com.softtek.web.cursos.web.service.CoursesService;

@Controller
public class WebControllerApp {
	
	@Autowired
	CoursesService coursesService;
	
	@GetMapping("/index.html")
	public String goHomePage(Model model) {
		
		List<Courses> courses = coursesService.getAllCourses();
		
		model.addAttribute("courses", courses);
		
		return "index";
	}
	
		@GetMapping("/contact.html")
		public String goContactPage() {
			return "contact";
	}
		@GetMapping("/blog.html")
		public String goBlogPage() {
			return "blog";
	}
		
		@GetMapping("/blog-post.html")
		public String goBlogPostPage() {
			return "blog-post";
	}
		
}
