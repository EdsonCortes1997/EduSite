package com.softtek.web.cursos.web.repository;



import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.softtek.web.cursos.web.entity.Courses;


@Repository
public interface CoursesRepository extends CrudRepository<Courses , Long> {
	

}
