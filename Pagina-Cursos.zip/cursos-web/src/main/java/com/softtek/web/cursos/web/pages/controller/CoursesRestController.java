package com.softtek.web.cursos.web.pages.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.softtek.web.cursos.web.entity.Courses;
import com.softtek.web.cursos.web.service.CoursesService;

@RestController
public class CoursesRestController {
	
	@Autowired
	CoursesService courseServiceImpl;
	
	@GetMapping (value ="/allCourses")
	public List<Courses> getCoursesList(){
		return courseServiceImpl.getAllCourses();
	}
	

}
