package com.softtek.web.cursos.web;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CursosWebApplication {

	public static void main(String[] args) {
		SpringApplication.run(CursosWebApplication.class, args);
	}

}
