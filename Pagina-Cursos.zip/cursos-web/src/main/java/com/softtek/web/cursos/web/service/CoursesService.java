package com.softtek.web.cursos.web.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.softtek.web.cursos.web.entity.Courses;
import com.softtek.web.cursos.web.repository.CoursesRepository;

@Service
public class CoursesService {

	private CoursesRepository coursesRepository;

	@Autowired
	public CoursesService(CoursesRepository coursesRepository) {
		this.coursesRepository = coursesRepository;
	}

	public List<Courses> getAllCourses() {
		List<Courses> courses = (List<Courses>) coursesRepository.findAll();
		return courses;
	}
}
